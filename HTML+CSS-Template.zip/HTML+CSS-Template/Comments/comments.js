/* createLanding()
{
let landingDiv = document.createElement("div");
landingDiv.setAttribute("class","landing");
landingDiv.setAttribute("id","landing");

let landingContainer = document.createElement("div");
landingContainer.setAttribute("class","container");

let landingText =document.createElement("div");
landingText.setAttribute("class" , "text");

let  landingh2 =document.createElement("h2");
 let text=document.createTextNode(" Welcome to ElAhmed World ");
 landingh2.appendChild(text);

let landingP=document.createElement("p");
let par=document.createTextNode("Here Iam gonna share everything about my life. Books Iam reading, Games Iam Playing, Stories and Events");
landingP.appendChild(par);

let landingImg =document.createElement("div");
landingImg.setAttribute("class","image");

let imgs = document.createElement("img");
imgs.setAttribute("src" , "imgs/landing-image.png");
imgs.setAttribute("alt","");

let anchorDown = document.createElement("a");
anchorDown.setAttribute("href","#articles");
anchorDown.setAttribute("class","go-down");

let iconDown=document.createElement("i");
iconDown.setAttribute("class" , " fas fa-angle-double-down fa-2x");

console.log(landingDiv);

//landing appending

landingDiv.appendChild(landingContainer);
landingContainer.appendChild(landingText);
landingText.appendChild(landingh2);
landingText.appendChild(landingP);

landingContainer.appendChild(landingImg);
landingImg.appendChild(imgs);

landingContainer.appendChild(anchorDown);
anchorDown.appendChild(iconDown);

//Start Article

function article(){
let article = document.createElement("div");
article.setAttribute("class","articles");
article.setAttribute("id","articles");

let mainTitle = document.createElement("h2");
mainTitle.setAttribute("class","main-title");
let titleText = document.createTextNode("Articles");
mainTitle.appendChild(titleText);

let articleContainer =document.createElement("div");
articleContainer.setAttribute("class","container");

for(let i=1 ;i<9;i++){
    let articleBox =document.createElement("div");
    articleBox.setAttribute("class" , "box");
    let articleImg = document.createElement("img");
    articleImg.setAttribute("src","imgs/cat-0"+ i +".jpeg");

    articleContainer.appendChild(articleBox);
    articleBox.appendChild(articleImg);

    let content = document.createElement("div");
    content.setAttribute("class","content");
    articleBox.appendChild(content);

    let contenth3 =document.createElement("h3");
    let h3Text = document.createTextNode("Test Title");
    contenth3.appendChild(h3Text)
    content.appendChild(contenth3);

    let contentP= document.createElement("p");
    let pText =document.createTextNode("Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit");
    contentP.appendChild(pText);
    content.appendChild(contentP);

    let articleInfo = document.createElement("div");
    articleInfo.setAttribute("class","info");

    articleBox.appendChild(articleInfo);

    let articleA= document.createElement("a");
    articleA.setAttribute("href" , "");
    let articleAText = document.createTextNode("Read More");
    articleA.appendChild(articleAText);

    articleInfo.appendChild(articleA);

    let articleIcon =document.createElement("i");
    articleIcon.setAttribute("class","fas fa-long-arrow-alt-right");

    articleInfo.append(articleIcon);

}

Appending Articles

   article.appendChild(mainTitle);
   article.appendChild(articleContainer);

    console.log(article);

add event to choose plan

body appending

document.body.prepend(article);
document.body.prepend(landingDiv);
document.body.prepend(mainHeader);
}*/
