function createHeader() {
  //create elements;

  let mainHeader = document.createElement("div");
  mainHeader.setAttribute("class", "header");
  mainHeader.setAttribute("id", "header");

  let container = document.createElement("div");
  container.setAttribute("class", "container");

  let anchor = document.createElement("a");
  anchor.setAttribute("href", "#");
  anchor.setAttribute("class", "logo");
  anchorText = document.createTextNode("El Ahmed");
  anchor.appendChild(anchorText);

  // Start Mega
  let mega = document.createElement("div");
  mega.setAttribute("class", "mega-menu");
  let image = document.createElement("div");
  image.setAttribute("class", "image");
  let img = document.createElement("img");
  img.setAttribute("src", "imgs/megamenu.png");
  img.setAttribute("alt", "");

  let megaUl = document.createElement("ul");
  megaUl.setAttribute("class", "links");

  let megaUl2 = document.createElement("ul");
  megaUl2.setAttribute("class", "links");

  const megaNumbers = document.querySelectorAll(".M");
  console.log(megaNumbers);
  //lists
  for (const meg of megaNumbers) {
    let megaList1 = document.createElement("li");
    let megaAnchor1 = document.createElement("a");
    const megText = meg.getAttribute("data-nav");
    const megLink = "#" + megText;
    megaAnchor1.setAttribute("href", megLink);
    // megaList.appendChild(megaAnchor);
    let megaIconText1 = document.createTextNode(megText);
    let megaIcon1 = document.createElement("i");
    megaIcon1.setAttribute("class", "far fa-user fa-fw");

    //appending
    megaUl.appendChild(megaList1);
    //megaUl2.appendChild(megaList1);
    mega.appendChild(megaUl);
    //mega.appendChild(megaUl2);
    megaList1.appendChild(megaAnchor1);
    megaIcon1.appendChild(megaIconText1);
    megaAnchor1.appendChild(megaIcon1);

    image.appendChild(img);
    mega.appendChild(image);
  }
  //end Mega

  // Start List

  let ullist1 = document.createElement("ul");
  ullist1.setAttribute("class", "main-nav");
  const sectionNumbers = document.querySelectorAll("section");
  console.log(sectionNumbers);
  let list1 = document.createElement("li");
  for (let section of sectionNumbers) {
    let list1 = document.createElement("li");
    let anchorList1 = document.createElement("a");

    const anchorText = section.getAttribute("data-nav");
    const anchorLink = "#" + anchorText;

    anchorList1.setAttribute("href", anchorLink);
    anchorListText1 = document.createTextNode(anchorText);
    anchorList1.appendChild(anchorListText1);
    ullist1.appendChild(list1);
    list1.appendChild(anchorList1);
    list1.appendChild(mega);
    container.appendChild(ullist1);
    container.appendChild(anchor);
  }
  //end list

  console.log(mainHeader);
  // Header appending
  mainHeader.appendChild(container);
  container.prepend(anchor);

  
  document.body.prepend(mainHeader);
}



//Chossing plan alert message 


const plans = document.querySelectorAll("plans");

for (let plan of plans) {
  
}
  plan.addEventListener("click" , function(){

  alert("Congratulations you already subscribed Please contact us to activate your plan ")
});
console.log(plans);




//Post Request 

const postData = async ( url = '', data = {})=>{
  console.log(data)
    const response = await fetch(url, {
    method: 'POST', 
    credentials: 'same-origin',
    headers: {
        'Content-Type': 'application/json',
    },
   // Body data type must match "Content-Type" header        
    body: JSON.stringify(data), 
  });

    try {
      const newData = await response.json();
      console.log(newData);
      return newData;
    }catch(error) {
    console.log("error", error);
    }




}



const submit = document.getElementById("submit");

submit.addEventListener("click", mail);


function mail()
{
  const name = document.getElementById("name").value;
  const mail = document.getElementById("email").value;
  const phone= document.getElementById("phone").value;
  const feel = document.getElementById("feel").value;

  if (name.trim("") == "" || mail.trim("") == "" ) {
    // if you click to the button and the inputs are empty we will show to the user the alert message bellow
    alert("name or mail is Empty");
    return;
  }

  else{


  console.log("Your Name :/n" +name+ " " + "Your E-mail:/n" + mail + " " + " Your Phone:/n"+phone+ " " +" Ypur Feeling " + feel);
  alert("Your Data has been submitted ")
  return;
  }


}

  
const sub = document.getElementById("sub");

sub.addEventListener("click",subscribe)


function subscribe()
{
  const email= document.getElementById("emailSub").value;
  if (email.trim("") == "") {
    // if you click to the button and the inputs are empty we will show to the user the alert message bellow
    alert("E-mail is Empty");
    return;
  }
  else{
  console.log("Your E-mail : " + email);
  alert("Your Are Subscribed ");
  return;
  }




}

function countDown(){
  
  var countDownDate = new Date("Jan 5, 2024 15:37:25").getTime();

  // Update the count down every 1 second
  var x = setInterval(function() {
  
    // Get today's date and time
    var now = new Date().getTime();
  
    // Find the distance between now and the count down date
    var distance = countDownDate - now;
  



    // Time calculations for days, hours, minutes and seconds
    var days = document.getElementById("Days");
    var hours = document.getElementById("hours");
    var minutes = document.getElementById("min");
    var seconds = document.getElementById("sec");


    // logic


     var day = Math.floor(distance / (1000 * 60 * 60 * 24));
     var hour = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
     var min = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
     var sec = Math.floor((distance % (1000 * 60)) / 1000);
  
    // Display the result in the element with id="demo"
    //document.getElementById("demo").innerHTML = days + "d " + hours + "h "
    //+ minutes + "m " + seconds + "s ";

    days.innerHTML=day;
    hours.innerHTML=hour;
    minutes.innerHTML=min;
    seconds.innerHTML=sec;





  
    // If the count down is finished, write some text 
    if (distance < 0) {
      clearInterval(x);
      document.getElementById("demo").innerHTML = "EXPIRED";
    }
  }, 1000);
 

}

// const up = document.getElementById("up");
// // console.log(up)
//  up.addEventListener("click",function(){
//   up.setAttribute("class","scroll-to-top span");
//   up.setAttribute("href","#header");
//   up.setAttribute("style","display: block;");
//  });

 function upHome()
 {
  const up = document.getElementById("up");
   up.setAttribute("class","scroll-to-top");
   up.setAttribute("href","#header");
   
   
 }




//toggle Functions
upHome();
createHeader();
countDown()
