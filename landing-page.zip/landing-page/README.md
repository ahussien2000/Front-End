# Landing Page Project

## Autor

Ahmed Hussein Ismaeel Mostafa

## description

This Project talks about multi-section landing page . We have in our project a navigation bar was built dynamically also we have 4 sections on the page when we click on the section name on the navigation bar, the window will scroll to the section we clicked and at the same time, the link in the navigation bar and the section will have active class.
We have a button called logo on the left side of the navigation bar when we click on it will go up to the home of the page. We also have a button called "collapsible" this button can close and open the next section when we click on it

The Function I Used:
1-Home: This function created a logo button on the navigation bar.
2-Scrolling: The function depends on Events when we scroll the window the section and the link will be active.
3-collapsible: This function created a button called "collapsible" to open and close the next section.
4-nav menu: This function created a dynamic navigation bar.
5-time: this function alert message when you stopped to scroll after 5 second

The Style I Used:
1- Home Style.
2- collapsible Style.
3-Some Of the Responsive style "@media".

## Technologies

HTML , CSS , JvaScript ,DOM , Arrow Function,ES6,ES7

## Quotations of codes from external sites

1- Just The Idea of the collapsible from W3School.
2- nextElementSibling , setTimeout() , clearTime() from => MDN documentation.
3- Time function idea from Go Make Things website .
